read -p "Enter username: " USER_NAME && java -cp ubercube.jar fr.veridiangames.client.MainComponent 91.134.107.165:4242 $USER_NAME
